--よみがなチェック
SELECT sakumotsu, betsumei, ruby FROM m_sakumotsu WHERE NOT REGEXP('^[ 0-9A-Za-z\.\-,%<>ぁ-ゔヴー～、。・()\[\]]+$', ruby, '');
SELECT byochu, betsumei FROM m_byochu WHERE NOT REGEXP('^[ 0-9A-Za-z\.\-,%<>ぁ-ゔヴー～、。・()\[\]]+$', betsumei, '');
SELECT kws, re_replace('^.*;', kws, '') as ruby FROM kwlists WHERE NOT REGEXP('^[ 0-9A-Za-z\.\-,%<>ぁ-ゔヴー～、。・()\[\]]+$', ruby, '');
