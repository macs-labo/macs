WITH
	yago1 AS (SELECT bango, meisho, tsusho, REPLACE(meisho, tsusho, '') AS yago FROM m_kihon WHERE meisho != tsusho ORDER BY yago),
	yago2 AS (SELECT DISTINCT yago FROM yago1 WHERE meisho != yago AND yago NOT LIKE '%)')
SELECT bango, meisho, tsusho FROM m_kihon WHERE like_in(tsusho, (SELECT json_group_array(if(yago in ('N', 'SG', 'キング', 'アース'), '', '%')||yago||'%') FROM yago2)) --AND meisho = tsusho 
