/* 殺虫剤 IRAC 分類表 (コード表掲載全有効成分一覧) */
select mid, sayokiko, sayoten, keito, ippanmei from irac_ai left join irac_sg using(sid) left join irac_mg using(mid) where mid != '未';
