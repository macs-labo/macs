/* 殺虫剤 IRAC 分類表 (コード表掲載全有効成分一覧) */
/* @filename: "IRAC分類(全有効成分一覧).sql"       */
select re_replace('^([1-9](\(?[A-Z]\)?)?)$', mid, ' $1') as mid, sayokiko, sayoten, keito, ippanmei from irac_ai left join irac_sg using(sid) left join irac_mg using(mid) where mid != '未' order by mid;
