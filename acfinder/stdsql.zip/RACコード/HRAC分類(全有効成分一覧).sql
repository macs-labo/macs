/* 除草剤 HRAC 分類表 (コード表掲載全有効成分一覧) */
select mid, lhrac as 旧分類, sayokiko, sayoten, keito, ippanmei from hrac_ai left join hrac_sg using(sid) left join hrac_mg using(mid) where mid != '未';
