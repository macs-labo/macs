/* 殺菌剤 FRAC 分類表2 (薬剤通称一覧) */
drop table if exists tSql1;
create temp table tSql1 as select distinct re_replace('^(くり|不可欠用途|検疫|.*農地)専用|^(くん蒸|微量注入|粉衣|塗布|緑化|側条|きのこ|わさび|芝|大豆|(家庭)?園芸|(野菜類)?種子消毒)(用)?|^(ヤシマ|NT|エキカ)|粒状(水中)?|固形|強力|防散|撒粉|なげこみ|\(粉状\)', re_replace('((ZY)?-?[0-9]\.?[0-9]*(?![,\-]|号))(グラム|キロ|[GQNSW%]|D(?![FL]))?', tsusho, ''), '') as tsusho, ippanmei, seibun, if(kongo=1,'',(select concat('/', mid) from kihon where bango = a.bango and ippanmei <> a.ippanmei and mid not like '%未' group by bango)) as rac from kihon as a order by tsusho;
update tSql1 set rac = '['||replace(rac, 'F:', '')||']' where rac <> '';
drop table if exists tSql2;
create temp table tSql2 as select ippanmei, seibun,
--gn_concat(', ', tsusho||rac) as tsusho
gn_concat(', ', re_replace('( |・)?(-?AL|DF|DG|EC|ES|EW|FG|FS|GT|iQ|ME|MK|SC|SE|SG|SL|OD|OS|WD?G|WP|エアー|エアゾール|ゾル|シャワー|(?<!ナイ)スプレー|(マイクロ)?カプセル|顆粒|粉末|小球|原液|塗布剤|粉衣剤|注入剤|アクア(キャップ)?|オイル|ペースト|くん(煙|蒸)(剤)?|(小型)?錠(剤)?|[AGSX]?乳剤|液(剤)?S?|水(和|溶)剤|[HLRZ]?フロアブル[HL]?|((?<!D)[HLRSZ] ?)?ジャンボ[HLP]?|((?<!ル)S|(?<!WR)|[HLUZ]|CR|MC)?(箱|微|粉|細)?粒剤[FHL]?|[HLR]?豆つぶ|((?<!クス)H|[FL])?粉剤(DL)?|S?油剤[CD]?|MC$|ジェット$|ベイト$|(?<!トス)パック$)', tsusho, '')||rac) as tsusho
from tSql1 group by ippanmei;
drop table tSql1; 
select mid, sayokiko, sayoten, fgroup as FRAC系統, keito, risk, ippanmei, tsusho from frac_ai left join frac_sg using(sid) left join frac_mg using(mid) left join tSql2 using(ippanmei) where seibun is not null;
