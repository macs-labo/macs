/* 殺菌剤 FRAC 分類表 (コード表掲載全有効成分一覧) */
/* @filename: "FRAC分類(全有効成分一覧).sql"       */
select re_replace('^([1-9])$', mid, ' $1') as mid, sayokiko, sayoten, keito, ippanmei, fgroup as FRAC系統, risk from frac_ai left join frac_sg using(sid) left join frac_mg using(mid) where mid != '未' order by mid;
