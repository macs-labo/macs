/* 殺菌剤 FRAC 分類表 (コード表掲載全有効成分一覧) */
select mid, sayokiko, sayoten, keito, ippanmei, fgroup as FRAC系統, risk from frac_ai left join frac_sg using(sid) left join frac_mg using(mid) where mid != '未';
