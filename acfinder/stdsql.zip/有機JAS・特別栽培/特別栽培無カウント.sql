/* 特別栽培無カウント農薬一覧作成クエリー 2025.12.2版 @filename: "特別栽培無カウント"
　有機農産物の日本農林規格(農林水産省告示)の「表B.1」の農薬及び化学合成されていない農薬の一覧表を作成します。
　根拠告示の日付・番号は「有機JAS告示.qry」を読み込んで実行すると確認できます。 
　同じ有効成分でも剤型によっては化学合成されていたり、同じ製品名でも有効成分が天然物であったり化学合成物であったりします。また、同一製剤でも、認証団体によってカウントされたりされなかったりということもあります。リストされた農薬の使用に当たっては、必ず農薬メーカーやそれぞれの認証団体にご確認ください。

[参考文献]
https://www.maff.go.jp/j/jas/jas_kikaku/attach/pdf/yuuki-437.pdf
https://www.maff.go.jp/j/jas/jas_kikaku/attach/pdf/tokusai_a-5.pdf
https://www.maff.go.jp/j/jas/jas_kikaku/pdf/tokusai_qa.pdf
https://www.pref.ibaraki.jp/nourinsuisan/nougi/tokusai/documents/decrease_nouyaku.pdf
https://www.pref.tochigi.lg.jp/g04/work/nougyou/seisan-ryuutsuu/documents/nouyakuseibun.pdf
https://www.pref.kanagawa.jp/documents/30837/tokusainouyaku.pdf
https://www.pref.aichi.jp/uploaded/attachment/509363.pdf
https://www.pref.fukui.lg.jp/doc/021033/ekonougyou/sin-ninshouseido_d/fil/080.pdf
https://www.pref.wakayama.lg.jp/prefg/072000/tokusai/index_d/fil/noncount.pdf
https://www.pref.shimane.lg.jp/industry/norin/seisan/kankyo_suishin/ecoyuki/eco/kauntonouyaku.html
https://www.pref.tokushima.lg.jp/file/attachment/88218.pdf
https://www.pref.saga.lg.jp/kiji00385765/3_85765_240676_up_le5k7xwh.pdf
https://www.pref.miyazaki.lg.jp/nogyofukyugijutsu/shigoto/nogyo/kangaekata.html
http://www.kaken.co.jp/static/nou_doubutsu/agro/polioxin/tokusai_3.pdf
*/
SELECT * FROM kihon WHERE bango IN (SELECT bango FROM t_tokusai);
